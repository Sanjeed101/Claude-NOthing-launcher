package com.dotlauncher.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** A 5x7 dot-matrix typeface, drawn as circles. */
object DotFont {
    private val glyphs: Map<Char, Array<String>> = mapOf(
        '0' to arrayOf(".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."),
        '1' to arrayOf("..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."),
        '2' to arrayOf(".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"),
        '3' to arrayOf("#####", "...#.", "..#..", "...#.", "....#", "#...#", ".###."),
        '4' to arrayOf("...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."),
        '5' to arrayOf("#####", "#....", "####.", "....#", "....#", "#...#", ".###."),
        '6' to arrayOf("..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."),
        '7' to arrayOf("#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."),
        '8' to arrayOf(".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."),
        '9' to arrayOf(".###.", "#...#", "#...#", ".####", "....#", "...#.", ".##.."),
        'A' to arrayOf(".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
        'B' to arrayOf("####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."),
        'C' to arrayOf(".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."),
        'D' to arrayOf("###..", "#..#.", "#...#", "#...#", "#...#", "#..#.", "###.."),
        'E' to arrayOf("#####", "#....", "#....", "####.", "#....", "#....", "#####"),
        'F' to arrayOf("#####", "#....", "#....", "####.", "#....", "#....", "#...."),
        'G' to arrayOf(".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"),
        'H' to arrayOf("#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
        'I' to arrayOf(".###.", "..#..", "..#..", "..#..", "..#..", "..#..", ".###."),
        'J' to arrayOf("..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."),
        'K' to arrayOf("#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"),
        'L' to arrayOf("#....", "#....", "#....", "#....", "#....", "#....", "#####"),
        'M' to arrayOf("#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"),
        'N' to arrayOf("#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"),
        'O' to arrayOf(".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
        'P' to arrayOf("####.", "#...#", "#...#", "####.", "#....", "#....", "#...."),
        'Q' to arrayOf(".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"),
        'R' to arrayOf("####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"),
        'S' to arrayOf(".####", "#....", "#....", ".###.", "....#", "....#", "####."),
        'T' to arrayOf("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."),
        'U' to arrayOf("#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
        'V' to arrayOf("#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."),
        'W' to arrayOf("#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."),
        'X' to arrayOf("#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"),
        'Y' to arrayOf("#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."),
        'Z' to arrayOf("#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"),
        ':' to arrayOf(".", ".", "#", ".", "#", ".", "."),
        '.' to arrayOf(".", ".", ".", ".", ".", ".", "#"),
        '-' to arrayOf("....", "....", "....", "####", "....", "....", "...."),
        '%' to arrayOf("##...", "##..#", "...#.", "..#..", ".#...", "#..##", "...##"),
        '/' to arrayOf("....#", "...#.", "...#.", "..#..", ".#...", ".#...", "#...."),
        '\u00B0' to arrayOf(".#.", "#.#", ".#.", "...", "...", "...", "..."),
        '\u2600' to arrayOf("...#...", ".#...#.", "..###..", "#.###.#", "..###..", ".#...#.", "...#..."),
        '\u2601' to arrayOf(".......", "..##...", ".####..", ".#####.", "#######", "#######", "......."),
        '\u2602' to arrayOf("..##...", ".####..", "######.", ".......", ".#.#.#.", "#.#.#..", "......."),
        '\u26A1' to arrayOf("..###..", ".#####.", "#######", "...#...", "..#....", ".####..", "...#..."),
        '\u2744' to arrayOf("...#...", ".#.#.#.", "..###..", "#######", "..###..", ".#.#.#.", "...#..."),
        '\u2261' to arrayOf(".......", "#######", ".......", "#######", ".......", "#######", "......."),
        ' ' to arrayOf("...", "...", "...", "...", "...", "...", "...")
    )

    fun glyph(c: Char): Array<String> = glyphs[c.uppercaseChar()] ?: glyphs.getValue(' ')

    fun columns(text: String): Int {
        if (text.isEmpty()) return 0
        var n = 0
        for (ch in text) n += glyph(ch)[0].length
        return n + text.length - 1
    }

    fun draw(
        canvas: Canvas, text: String, x: Float, y: Float, pitch: Float,
        paint: Paint, accent: Paint? = null, accentChars: String = "", off: Paint? = null
    ) {
        var cx = x
        val r = pitch * 0.4f
        for (ch in text) {
            val g = glyph(ch)
            val w = g[0].length
            val p = if (accent != null && accentChars.indexOf(ch) >= 0) accent else paint
            for (row in 0 until 7) {
                val line = g[row]
                for (col in 0 until w) {
                    val px = cx + col * pitch + pitch / 2f
                    val py = y + row * pitch + pitch / 2f
                    if (line[col] == '#') canvas.drawCircle(px, py, r, p)
                    else if (off != null) canvas.drawCircle(px, py, r, off)
                }
            }
            cx += (w + 1) * pitch
        }
    }
}

/** Text rendered in the dot-matrix font. Auto-fits to the available width, up to [maxPitch]. */
class DotTextView(ctx: Context) : View(ctx) {
    var text: String = ""
        set(v) {
            if (field != v) {
                field = v
                requestLayout()
                invalidate()
            }
        }
    var maxPitch: Float = ctx.dp(8f)
    var accentChars: String = ""
    var centered = false
    var showOffDots = false
    var color: Int
        get() = paint.color
        set(v) {
            paint.color = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.RED }
    private val off = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.DOT_OFF }
    private var pitch = maxPitch

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val cols = max(1, DotFont.columns(text))
        val mode = MeasureSpec.getMode(widthMeasureSpec)
        val size = MeasureSpec.getSize(widthMeasureSpec)
        val avail = (size - paddingLeft - paddingRight).toFloat()
        pitch = if (mode == MeasureSpec.UNSPECIFIED) maxPitch else max(1f, min(maxPitch, avail / cols))
        val w = if (mode == MeasureSpec.EXACTLY) size
        else min(if (mode == MeasureSpec.AT_MOST) size else Int.MAX_VALUE,
            (cols * pitch).roundToInt() + paddingLeft + paddingRight)
        val h = (7 * pitch).roundToInt() + paddingTop + paddingBottom
        setMeasuredDimension(w, resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val tw = DotFont.columns(text) * pitch
        val x = if (centered) (width - tw) / 2f else paddingLeft.toFloat()
        DotFont.draw(canvas, text, x, paddingTop.toFloat(), pitch, paint, accent, accentChars,
            if (showOffDots) off else null)
    }
}

/** Battery as a ring of dots with the percentage in the middle. */
class BatteryDotsView(ctx: Context) : View(ctx) {
    var level = 0
        set(v) {
            field = v
            invalidate()
        }
    var charging = false
        set(v) {
            field = v
            invalidate()
        }

    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT }
    private val low = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.RED }
    private val off = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.DOT_OFF }
    private val maxSize = ctx.dp(150)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val mode = MeasureSpec.getMode(widthMeasureSpec)
        val size = if (mode == MeasureSpec.UNSPECIFIED) maxSize else MeasureSpec.getSize(widthMeasureSpec)
        val s = min(size, maxSize)
        setMeasuredDimension(size, s)
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val dotR = s * 0.032f
        val ringR = s / 2f - dotR * 1.5f
        val n = 40
        val lit = (level * n + 50) / 100
        val litPaint = if (level <= 20 && !charging) low else on
        for (i in 0 until n) {
            val a = Math.toRadians(-90.0 + i * 360.0 / n)
            val px = cx + (ringR * cos(a)).toFloat()
            val py = cy + (ringR * sin(a)).toFloat()
            canvas.drawCircle(px, py, dotR, if (i < lit) litPaint else off)
        }
        val txt = level.toString()
        val pitch = s * 0.05f
        val tw = DotFont.columns(txt) * pitch
        DotFont.draw(canvas, txt, cx - tw / 2f, cy - 3.5f * pitch, pitch, on)
        if (charging) {
            canvas.drawCircle(cx, cy + 5.2f * pitch, pitch * 0.55f, low)
        }
    }
}

/** FrameLayout that turns swipes, double-taps and long-presses on empty space into callbacks. */
class SwipeFrame(ctx: Context) : FrameLayout(ctx) {
    companion object {
        const val UP = 0
        const val DOWN = 1
        const val LEFT = 2
        const val RIGHT = 3
        const val DOUBLE = 4
    }

    var onSwipe: ((Int) -> Unit)? = null
    var onLongPressAction: (() -> Unit)? = null
    var onDoubleTapAction: (() -> Unit)? = null
    var enabledDirs: Set<Int> = setOf(UP, DOWN)
    var canIntercept: (Int) -> Boolean = { true }

    var downRawX = 0f
        private set
    var downRawY = 0f
        private set

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var fired = false

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onLongPress(e: MotionEvent) {
            if (!fired) this@SwipeFrame.onLongPressAction?.invoke()
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val a = this@SwipeFrame.onDoubleTapAction ?: return false
            a()
            return true
        }
    })

    private fun dirOf(dx: Float, dy: Float): Int? = when {
        abs(dy) > abs(dx) * 1.3f -> if (dy < 0) UP else DOWN
        abs(dx) > abs(dy) * 1.3f -> if (dx < 0) LEFT else RIGHT
        else -> null
    }

    private fun start(ev: MotionEvent) {
        downX = ev.x
        downY = ev.y
        downRawX = ev.rawX
        downRawY = ev.rawY
        fired = false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> start(ev)
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                val d = dirOf(dx, dy)
                if (max(abs(dx), abs(dy)) > slop && d != null && d in enabledDirs && canIntercept(d)) {
                    return true
                }
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> start(ev)
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (!fired && max(abs(dx), abs(dy)) > slop * 3) {
                    val d = dirOf(dx, dy)
                    if (d != null && d in enabledDirs) {
                        fired = true
                        onSwipe?.invoke(d)
                    }
                }
            }
        }
        return true
    }
}
