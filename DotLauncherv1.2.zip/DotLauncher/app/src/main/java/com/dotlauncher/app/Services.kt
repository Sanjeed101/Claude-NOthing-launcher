package com.dotlauncher.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent

/** Reads notifications so the quick panel can show them. Needs "Notification access". */
class NotifService : NotificationListenerService() {
    companion object {
        @Volatile
        var instance: NotifService? = null
        var onChange: (() -> Unit)? = null
        private val main = Handler(Looper.getMainLooper())

        fun current(): List<StatusBarNotification> = try {
            instance?.activeNotifications?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

        fun changed() {
            main.post { onChange?.invoke() }
        }
    }

    override fun onListenerConnected() {
        instance = this
        changed()
    }

    override fun onListenerDisconnected() {
        instance = null
        changed()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = changed()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = changed()
}

/** Accessibility service used only for "lock screen" and opening the system shade. */
class LockService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: LockService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun lock(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
}
