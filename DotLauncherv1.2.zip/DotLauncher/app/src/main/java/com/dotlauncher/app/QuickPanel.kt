package com.dotlauncher.app

import android.app.Activity
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Nothing-style pull-down panel: toggles, brightness, media and notifications. */
class QuickPanel(
    private val act: Activity,
    private val is24: () -> Boolean
) {
    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    val view = SwipeFrame(act)
    var isOpen = false
        private set

    private val scroll = ScrollView(act)
    private val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val timeView = DotTextView(act)
    private val dateView = mono("", 11f, Pal.SUB)
    private val tiles = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val bright = SeekBar(act)
    private val media = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val notifs = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val main = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(act).scaledTouchSlop.toFloat()

    private val cam: CameraManager? = try { act.getSystemService(CameraManager::class.java) } catch (e: Exception) { null }
    private var torchId: String? = null
    private var torchOn = false
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) {
                torchOn = enabled
                if (isOpen) buildTiles()
            }
        }
    }

    init {
        view.setBackgroundColor(0xF5000000.toInt())
        view.visibility = View.GONE
        view.isClickable = true
        view.enabledDirs = setOf(SwipeFrame.UP)
        view.canIntercept = { !scroll.canScrollVertically(1) }
        view.onSwipe = { close() }

        scroll.isVerticalScrollBarEnabled = false
        scroll.isFillViewport = true
        view.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        // Header: time, date, settings shortcut
        val header = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        timeView.maxPitch = act.dp(7f)
        timeView.accentChars = ":"
        header.addView(timeView, lp(WRAP, WRAP))
        header.addView(View(act), lp(0, 1, 1f))
        val gear = pill("SETTINGS", false) { start(Intent(Settings.ACTION_SETTINGS)) }
        header.addView(gear, lp(WRAP, act.dp(38)))
        col.addView(header, lp(MATCH, WRAP))
        col.addView(dateView, lp(MATCH, WRAP).apply { topMargin = act.dp(10) })

        col.addView(tiles, lp(MATCH, WRAP).apply { topMargin = act.dp(22) })

        // Brightness
        val bCard = card()
        bCard.addView(mono("BRIGHTNESS", 10f, Pal.SUB), lp(MATCH, WRAP))
        bright.max = 255
        bright.progressTintList = ColorStateList.valueOf(Color.WHITE)
        bright.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        bright.progressBackgroundTintList = ColorStateList.valueOf(0xFF3A3A3A.toInt())
        bright.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) setBrightness(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                if (!Settings.System.canWrite(act)) requestWriteSettings()
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        bCard.addView(bright, lp(MATCH, WRAP).apply { topMargin = act.dp(10) })
        col.addView(bCard, lp(MATCH, WRAP).apply { topMargin = act.dp(12) })

        col.addView(media, lp(MATCH, WRAP))

        // Notifications header
        val nh = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        nh.addView(DotTextView(act).apply { text = "NOTIFICATIONS"; maxPitch = act.dp(3.2f) }, lp(WRAP, WRAP))
        nh.addView(View(act), lp(0, 1, 1f))
        nh.addView(mono("CLEAR ALL", 11f, Pal.RED).apply {
            setPadding(act.dp(10), act.dp(10), 0, act.dp(10))
            setOnClickListener { try { NotifService.instance?.cancelAllNotifications() } catch (e: Exception) {} }
        }, lp(WRAP, WRAP))
        col.addView(nh, lp(MATCH, WRAP).apply { topMargin = act.dp(26) })
        col.addView(notifs, lp(MATCH, WRAP).apply { topMargin = act.dp(6) })

        col.addView(View(act), lp(MATCH, 0, 1f))
        col.addView(mono("SWIPE UP TO CLOSE", 10f, Pal.DOT_OFF).apply { gravity = Gravity.CENTER },
            lp(MATCH, WRAP).apply { topMargin = act.dp(24) })

        try {
            val c = cam
            if (c != null) {
                torchId = c.cameraIdList.firstOrNull {
                    c.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                c.registerTorchCallback(torchCb, main)
            }
        } catch (e: Exception) {
        }
    }

    fun setInsets(l: Int, t: Int, r: Int, b: Int) {
        val pad = act.dp(18)
        col.setPadding(l + pad, t + act.dp(14), r + pad, b + act.dp(18))
    }

    fun open() {
        if (isOpen) return
        isOpen = true
        refresh()
        scroll.scrollTo(0, 0)
        view.visibility = View.VISIBLE
        view.animate().cancel()
        val h = if (view.height > 0) view.height.toFloat() else 1500f
        view.translationY = -h * 0.25f
        view.alpha = 0f
        view.animate().translationY(0f).alpha(1f).setDuration(240)
            .setInterpolator(DecelerateInterpolator(2f)).start()
    }

    fun close(animate: Boolean = true) {
        if (!isOpen) return
        isOpen = false
        view.animate().cancel()
        if (animate) {
            val h = if (view.height > 0) view.height.toFloat() else 1500f
            view.animate().translationY(-h * 0.25f).alpha(0f).setDuration(200)
                .setInterpolator(AccelerateInterpolator())
                .withEndAction { if (!isOpen) view.visibility = View.GONE }.start()
        } else {
            view.visibility = View.GONE
        }
    }

    fun refresh() {
        val now = Date()
        timeView.text = SimpleDateFormat(if (is24()) "HH:mm" else "h:mm", Locale.US).format(now)
        val bat = try { act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (e: Exception) { null }
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && scale > 0) "  ·  ${lvl * 100 / scale}%" else ""
        dateView.text = SimpleDateFormat("EEE d MMM", Locale.US).format(now).uppercase(Locale.US) + pct
        buildTiles()
        bright.progress = try { Settings.System.getInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
        buildMedia()
        buildNotifs()
    }

    // ---------------------------------------------------------------- tiles

    private class Tile(val label: String, val state: String, val active: Boolean, val onClick: () -> Unit)

    private fun buildTiles() {
        tiles.removeAllViews()
        val list = ArrayList<Tile>()

        val cm = try { act.getSystemService(ConnectivityManager::class.java) } catch (e: Exception) { null }
        val caps = try { cm?.let { it.getNetworkCapabilities(it.activeNetwork) } } catch (e: Exception) { null }
        val net = when {
            caps == null -> "OFFLINE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE DATA"
            else -> "ONLINE"
        }
        list.add(Tile("INTERNET", net, caps != null) {
            if (Build.VERSION.SDK_INT >= 29) start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            else start(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        })

        val bt = try {
            act.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (e: Exception) {
            false
        }
        list.add(Tile("BLUETOOTH", if (bt) "ON" else "OFF", bt) { start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })

        list.add(Tile("TORCH", if (torchOn) "ON" else "OFF", torchOn) {
            val id = torchId
            if (id != null) {
                try { cam?.setTorchMode(id, !torchOn) } catch (e: Exception) {}
            }
        })

        val nm = act.getSystemService(NotificationManager::class.java)
        val dnd = try { nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL } catch (e: Exception) { false }
        list.add(Tile("DO NOT DISTURB", if (dnd) "ON" else "OFF", dnd) {
            if (nm.isNotificationPolicyAccessGranted) {
                try {
                    nm.setInterruptionFilter(
                        if (dnd) NotificationManager.INTERRUPTION_FILTER_ALL
                        else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    )
                } catch (e: Exception) {}
                main.postDelayed({ if (isOpen) buildTiles() }, 250)
            } else {
                start(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        })

        val rot = try {
            Settings.System.getInt(act.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        } catch (e: Exception) {
            false
        }
        list.add(Tile("AUTO-ROTATE", if (rot) "ON" else "OFF", rot) {
            if (Settings.System.canWrite(act)) {
                try {
                    Settings.System.putInt(act.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (rot) 0 else 1)
                } catch (e: Exception) {}
                buildTiles()
            } else {
                requestWriteSettings()
            }
        })

        list.add(Tile("LOCATION", "SETTINGS", false) { start(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) })

        list.chunked(2).forEachIndexed { i, pair ->
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { j, t ->
                row.addView(tileView(t), lp(0, act.dp(86), 1f).apply { if (j == 0) rightMargin = act.dp(10) })
            }
            if (pair.size == 1) row.addView(View(act), lp(0, 1, 1f))
            tiles.addView(row, lp(MATCH, WRAP).apply { if (i > 0) topMargin = act.dp(10) })
        }
    }

    private fun tileView(t: Tile): View {
        val v = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (t.active) Color.WHITE else Pal.CARD, act.dp(24f))
            setPadding(act.dp(18), 0, act.dp(12), 0)
            isClickable = true
            setOnClickListener { t.onClick() }
        }
        v.addView(mono(t.label, 10f, if (t.active) 0xFF555555.toInt() else Pal.SUB), lp(MATCH, WRAP))
        v.addView(TextView(act).apply {
            text = t.state
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(if (t.active) Color.BLACK else Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, lp(MATCH, WRAP).apply { topMargin = act.dp(4) })
        return v
    }

    // ---------------------------------------------------------------- media

    private fun buildMedia() {
        media.removeAllViews()
        val sbn = NotifService.current().firstOrNull {
            it.notification.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)
        } ?: return
        @Suppress("DEPRECATION")
        val token = sbn.notification.extras.getParcelable<MediaSession.Token>(Notification.EXTRA_MEDIA_SESSION) ?: return
        val mc = try { MediaController(act, token) } catch (e: Exception) { return }
        val md = mc.metadata
        val ex = sbn.notification.extras
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Now playing"
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val playing = mc.playbackState?.state == PlaybackState.STATE_PLAYING

        val c = card()
        c.addView(mono(appName(sbn.packageName), 10f, Pal.SUB), lp(MATCH, WRAP))
        c.addView(TextView(act).apply {
            text = title
            textSize = 17f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, lp(MATCH, WRAP).apply { topMargin = act.dp(8) })
        if (artist.isNotEmpty()) c.addView(TextView(act).apply {
            text = artist
            textSize = 13f
            setTextColor(Pal.SUB)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, lp(MATCH, WRAP))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val tc = mc.transportControls
        row.addView(pill("PREV", false) { tc.skipToPrevious(); later() }, lp(0, act.dp(42), 1f))
        row.addView(pill(if (playing) "PAUSE" else "PLAY", true) {
            if (playing) tc.pause() else tc.play()
            later()
        }, lp(0, act.dp(42), 1f).apply { leftMargin = act.dp(8); rightMargin = act.dp(8) })
        row.addView(pill("NEXT", false) { tc.skipToNext(); later() }, lp(0, act.dp(42), 1f))
        c.addView(row, lp(MATCH, WRAP).apply { topMargin = act.dp(14) })
        media.addView(c, lp(MATCH, WRAP).apply { topMargin = act.dp(12) })
    }

    private fun later() {
        main.postDelayed({ if (isOpen) buildMedia() }, 450)
    }

    // ---------------------------------------------------------------- notifications

    private fun listenerEnabled(): Boolean = try {
        Settings.Secure.getString(act.contentResolver, "enabled_notification_listeners")
            ?.contains(act.packageName) == true
    } catch (e: Exception) {
        false
    }

    fun buildNotifs() {
        notifs.removeAllViews()
        if (!listenerEnabled()) {
            val c = card()
            c.addView(TextView(act).apply {
                text = "Show your notifications here"
                textSize = 15f
                setTextColor(Color.WHITE)
            }, lp(MATCH, WRAP))
            c.addView(TextView(act).apply {
                text = "Tap to allow notification access for Dot Launcher. If the switch is greyed out, " +
                    "open App info for Dot Launcher, tap ⋮ (top right) → Allow restricted settings, then try again."
                textSize = 12.5f
                setTextColor(Pal.SUB)
            }, lp(MATCH, WRAP).apply { topMargin = act.dp(6) })
            c.isClickable = true
            c.setOnClickListener { start(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            notifs.addView(c, lp(MATCH, WRAP).apply { topMargin = act.dp(6) })
            return
        }
        val items = NotifService.current().filter { sbn ->
            val n = sbn.notification
            val ex = n.extras
            (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                !ex.containsKey(Notification.EXTRA_MEDIA_SESSION) &&
                sbn.packageName != act.packageName &&
                (!ex.getCharSequence(Notification.EXTRA_TITLE).isNullOrEmpty() ||
                    !ex.getCharSequence(Notification.EXTRA_TEXT).isNullOrEmpty())
        }.sortedByDescending { it.postTime }
        if (items.isEmpty()) {
            notifs.addView(mono("NO NOTIFICATIONS", 11f, Pal.DOT_OFF).apply {
                gravity = Gravity.CENTER
                setPadding(0, act.dp(24), 0, act.dp(24))
            }, lp(MATCH, WRAP))
            return
        }
        for (sbn in items) notifs.addView(notifCard(sbn), lp(MATCH, WRAP).apply { topMargin = act.dp(8) })
    }

    private fun notifCard(sbn: StatusBarNotification): View {
        val n = sbn.notification
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty()
        val c = card()
        val top = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = ImageView(act)
        try {
            val d = n.smallIcon?.loadDrawable(act)
            d?.setTint(Color.WHITE)
            icon.setImageDrawable(d)
        } catch (e: Exception) {}
        top.addView(icon, lp(act.dp(16), act.dp(16)))
        top.addView(mono(appName(sbn.packageName), 10f, Pal.SUB), lp(0, WRAP, 1f).apply { leftMargin = act.dp(8) })
        top.addView(mono(SimpleDateFormat(if (is24()) "HH:mm" else "h:mm a", Locale.US).format(Date(sbn.postTime)),
            10f, Pal.SUB), lp(WRAP, WRAP))
        c.addView(top, lp(MATCH, WRAP))
        if (title.isNotEmpty()) c.addView(TextView(act).apply {
            this.text = title
            textSize = 14.5f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, lp(MATCH, WRAP).apply { topMargin = act.dp(8) })
        if (text.isNotEmpty()) c.addView(TextView(act).apply {
            this.text = text
            textSize = 13f
            setTextColor(0xFFB4B4B4.toInt())
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
        }, lp(MATCH, WRAP).apply { topMargin = act.dp(3) })

        c.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var dragging = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        dragging = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        if (!dragging && abs(dx) > slop) {
                            dragging = true
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                        }
                        if (dragging) {
                            v.translationX = dx
                            v.alpha = 1f - min(1f, abs(dx) / max(1, v.width))
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = e.rawX - sx
                        if (dragging) {
                            if (abs(dx) > v.width * 0.35f && sbn.isClearable) {
                                v.animate().translationX(if (dx > 0) v.width.toFloat() else -v.width.toFloat())
                                    .alpha(0f).setDuration(150)
                                    .withEndAction { dismiss(sbn) }.start()
                            } else {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                        } else {
                            openNotification(sbn)
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                }
                return true
            }
        })
        return c
    }

    private fun dismiss(sbn: StatusBarNotification) {
        try { NotifService.instance?.cancelNotification(sbn.key) } catch (e: Exception) {}
    }

    private fun openNotification(sbn: StatusBarNotification) {
        val pi = sbn.notification.contentIntent
        if (pi != null) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    val opts = ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                        .toBundle()
                    pi.send(act, 0, null, null, null, null, opts)
                } else {
                    pi.send()
                }
            } catch (e: Exception) {}
        }
        if ((sbn.notification.flags and Notification.FLAG_AUTO_CANCEL) != 0) dismiss(sbn)
        close(false)
    }

    // ---------------------------------------------------------------- helpers

    private fun setBrightness(v: Int) {
        if (!Settings.System.canWrite(act)) return
        try {
            Settings.System.putInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS, max(1, v))
        } catch (e: Exception) {}
    }

    private fun requestWriteSettings() {
        start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + act.packageName)))
    }

    private fun appName(pkg: String): String = try {
        val pm = act.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg.substringAfterLast('.')
    }

    private fun start(i: Intent) {
        try {
            act.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun rounded(color: Int, r: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r
    }

    private fun card() = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Pal.CARD, act.dp(24f))
        setPadding(act.dp(18), act.dp(16), act.dp(18), act.dp(16))
    }

    private fun mono(t: String, sp: Float, color: Int) = TextView(act).apply {
        text = t
        textSize = sp
        setTextColor(color)
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.08f
        isAllCaps = true
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun pill(t: String, filled: Boolean, onClick: () -> Unit) = TextView(act).apply {
        text = t
        textSize = 11f
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.08f
        gravity = Gravity.CENTER
        setTextColor(if (filled) Color.BLACK else Color.WHITE)
        background = rounded(if (filled) Color.WHITE else 0xFF1E1E1E.toInt(), act.dp(21f))
        setPadding(act.dp(16), 0, act.dp(16), 0)
        isClickable = true
        setOnClickListener { onClick() }
    }
}
