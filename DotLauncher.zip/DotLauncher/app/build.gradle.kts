plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dotlauncher.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dotlauncher.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }

    signingConfigs {
        // Fixed key kept in the project so every build can update the previous install.
        create("dot") {
            storeFile = file("dotlauncher.jks")
            storePassword = "dotlauncher"
            keyAlias = "dot"
            keyPassword = "dotlauncher"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("dot")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
