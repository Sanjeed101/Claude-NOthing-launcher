package com.dotlauncher.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.roundToInt

/** Colour palette: black, white, greys and a single red accent. */
object Pal {
    val BG = Color.BLACK
    val CARD = 0xFF111111.toInt()
    val ICON_BG = 0xFF1E1E1E.toInt()
    val RED = 0xFFD71921.toInt()
    val TEXT = Color.WHITE
    val LABEL = 0xFFD6D6D6.toInt()
    val SUB = 0xFF8C8C8C.toInt()
    val DOT_OFF = 0xFF262626.toInt()
    val GRID = 0xFF1B1B1B.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dp(v: Float): Float = v * resources.displayMetrics.density

data class AppItem(
    val key: String,
    val label: String,
    val component: ComponentName,
    val user: UserHandle,
    val info: LauncherActivityInfo,
    val work: Boolean
)

object AppRepo {
    fun load(ctx: Context): List<AppItem> {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val um = ctx.getSystemService(UserManager::class.java)
        val me = Process.myUserHandle()
        val out = ArrayList<AppItem>()
        val users = try { um.userProfiles } catch (e: Exception) { listOf(me) }
        for (user in users) {
            val list = try { la.getActivityList(null, user) } catch (e: Exception) { emptyList() }
            val isWork = user != me
            val suffix = if (isWork) "#" + um.getSerialNumberForUser(user) else ""
            for (info in list) {
                val cn = info.componentName
                if (cn.packageName == ctx.packageName) continue
                out.add(
                    AppItem(
                        key = cn.flattenToString() + suffix,
                        label = info.label?.toString()?.trim().orEmpty().ifEmpty { cn.packageName },
                        component = cn,
                        user = user,
                        info = info,
                        work = isWork
                    )
                )
            }
        }
        return out.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dot", Context.MODE_PRIVATE)

    private fun bool(k: String, def: Boolean) = sp.getBoolean(k, def)
    private fun setBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var mono: Boolean
        get() = bool("mono", true)
        set(v) = setBool("mono", v)
    var dotGrid: Boolean
        get() = bool("dotGrid", true)
        set(v) = setBool("dotGrid", v)
    var clock24: Boolean
        get() = bool("clock24", true)
        set(v) = setBool("clock24", v)
    var labels: Boolean
        get() = bool("labels", true)
        set(v) = setBool("labels", v)
    var battery: Boolean
        get() = bool("battery", true)
        set(v) = setBool("battery", v)

    val pinsInitialized: Boolean get() = sp.contains("pins")
    var pins: List<String>
        get() = sp.getString("pins", "").orEmpty().split("|").filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("pins", v.joinToString("|")).apply()

    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet())?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("hidden", HashSet(v)).apply()
}

/** Renders app icons as uniform circles; monochrome mode uses themed-icon layers or greyscale. */
object Icons {
    private val cache = ConcurrentHashMap<String, Bitmap>()

    private fun key(app: AppItem, size: Int, mono: Boolean) = "${app.key}|$size|$mono"

    fun get(ctx: Context, app: AppItem, size: Int, mono: Boolean): Bitmap {
        val k = key(app, size, mono)
        cache[k]?.let { return it }
        val b = try { render(ctx, app, size, mono) } catch (e: Exception) { placeholder(size) }
        cache[k] = b
        return b
    }

    fun evict(pkg: String) {
        cache.keys.removeIf { it.startsWith("$pkg/") }
    }

    private fun placeholder(size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val s = size / 2f
        Canvas(b).drawCircle(s, s, s, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.ICON_BG })
        return b
    }

    private fun greyFilter(): ColorFilter {
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        val dim = ColorMatrix()
        dim.setScale(0.92f, 0.92f, 0.92f, 1f)
        cm.postConcat(dim)
        return ColorMatrixColorFilter(cm)
    }

    private fun render(ctx: Context, app: AppItem, size: Int, mono: Boolean): Bitmap {
        val dpi = ctx.resources.displayMetrics.densityDpi
        val d: Drawable = try { app.info.getIcon(dpi) } catch (e: Exception) { null }
            ?: ctx.packageManager.defaultActivityIcon
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()
        val clip = Path().apply { addCircle(s / 2f, s / 2f, s / 2f, Path.Direction.CW) }
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.ICON_BG }

        var monoLayer: Drawable? = null
        if (mono && Build.VERSION.SDK_INT >= 33 && d is AdaptiveIconDrawable) {
            monoLayer = d.monochrome
        }

        c.save()
        c.clipPath(clip)
        if (monoLayer != null) {
            // Themed-icon glyph: white on a dark circle.
            c.drawCircle(s / 2f, s / 2f, s / 2f, bg)
            val m = monoLayer.mutate()
            m.setTint(Color.WHITE)
            val span = s * 1.5f * 0.84f
            val off = (s - span) / 2f
            m.setBounds(off.roundToInt(), off.roundToInt(), (off + span).roundToInt(), (off + span).roundToInt())
            m.draw(c)
        } else if (d is AdaptiveIconDrawable) {
            val span = s * 1.5f
            val off = (s - span) / 2f
            val l = off.roundToInt()
            val r = (off + span).roundToInt()
            c.drawCircle(s / 2f, s / 2f, s / 2f, bg)
            for (layer in listOf(d.background, d.foreground)) {
                if (layer == null) continue
                val ly = layer.mutate()
                if (mono) ly.colorFilter = greyFilter()
                ly.setBounds(l, l, r, r)
                ly.draw(c)
            }
        } else {
            c.drawCircle(s / 2f, s / 2f, s / 2f, bg)
            val dd = d.mutate()
            if (mono) dd.colorFilter = greyFilter()
            val inset = (s * 0.17f).roundToInt()
            dd.setBounds(inset, inset, size - inset, size - inset)
            dd.draw(c)
        }
        c.restore()

        if (app.work) {
            // Small red dot marks work-profile apps.
            val r = s * 0.11f
            c.drawCircle(s - r * 1.4f, s - r * 1.4f, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.RED })
        }
        return bmp
    }
}

/** Tiled dot-grid background. */
class DotGridDrawable(spacing: Float, radius: Float, dotColor: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        val s = max(4, spacing.roundToInt())
        val tile = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(tile)
        c.drawColor(Color.BLACK)
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        dotPaint.color = dotColor
        c.drawCircle(s / 2f, s / 2f, radius, dotPaint)
        paint.shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    override fun draw(canvas: Canvas) {
        canvas.drawRect(bounds, paint)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
