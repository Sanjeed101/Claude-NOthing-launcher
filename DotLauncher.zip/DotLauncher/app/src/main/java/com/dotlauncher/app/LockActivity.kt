package com.dotlauncher.app

import android.app.Activity
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Nothing-style lock screen shown on top of the Samsung keyguard.
 * Swipe up hands over to the system (PIN / fingerprint), so security is unchanged.
 */
class LockActivity : Activity() {

    companion object {
        @Volatile
        var visible = false
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var prefs: Prefs
    private lateinit var content: LinearLayout
    private lateinit var hours: DotTextView
    private lateinit var minutes: DotTextView
    private lateinit var dateView: TextView
    private lateinit var infoView: TextView
    private lateinit var notifBox: LinearLayout
    private lateinit var torchBtn: TextView
    private val main = Handler(Looper.getMainLooper())

    private val cam: CameraManager? by lazy {
        try { getSystemService(CameraManager::class.java) } catch (e: Exception) { null }
    }
    private var torchId: String? = null
    private var torchOn = false
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) {
                torchOn = enabled
                styleTorch()
            }
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { update() }
    }

    /** Registered for the whole lifetime so a fingerprint unlock while the screen is off also closes us. */
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { finish() }
    }
    private var unlockRegistered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        if (!isLocked()) {
            finish()
            return
        }
        prefs = Prefs(this)
        try {
            val uf = IntentFilter(Intent.ACTION_USER_PRESENT)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(unlockReceiver, uf, Context.RECEIVER_EXPORTED)
            else registerReceiver(unlockReceiver, uf)
            unlockRegistered = true
        } catch (e: Exception) {}
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT

        val root = SwipeFrame(this)
        root.background = DotGridDrawable(dp(22f), dp(1.3f), Pal.GRID)
        root.enabledDirs = setOf(SwipeFrame.UP)
        root.onSwipe = { unlock() }
        root.onDoubleTapAction = { LockService.instance?.lock() }
        setContentView(root)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        root.setOnApplyWindowInsetsListener { _, wi ->
            val pad = dp(24)
            if (Build.VERSION.SDK_INT >= 30) {
                val s = wi.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                content.setPadding(s.left + pad, s.top + dp(36), s.right + pad, s.bottom + dp(20))
            } else {
                @Suppress("DEPRECATION")
                content.setPadding(wi.systemWindowInsetLeft + pad, wi.systemWindowInsetTop + dp(36),
                    wi.systemWindowInsetRight + pad, wi.systemWindowInsetBottom + dp(20))
            }
            wi
        }

        val wide = resources.configuration.screenWidthDp >= 600
        hours = DotTextView(this).apply { maxPitch = dp(if (wide) 20f else 17f); centered = true }
        minutes = DotTextView(this).apply { maxPitch = dp(if (wide) 20f else 17f); centered = true }
        content.addView(hours, lp(MATCH, WRAP))
        content.addView(minutes, lp(MATCH, WRAP).apply { topMargin = dp(14) })

        dateView = mono("", 13f, Pal.TEXT).apply { gravity = Gravity.CENTER }
        content.addView(dateView, lp(MATCH, WRAP).apply { topMargin = dp(26) })
        infoView = mono("", 11f, Pal.SUB).apply { gravity = Gravity.CENTER }
        content.addView(infoView, lp(MATCH, WRAP).apply { topMargin = dp(8) })

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        notifBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(notifBox, FrameLayout.LayoutParams(MATCH, WRAP))
        content.addView(scroll, lp(if (wide) dp(460) else MATCH, 0, 1f).apply { topMargin = dp(28) })

        // Bottom row: torch · hint · camera
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        torchBtn = roundButton("TORCH") { toggleTorch() }
        bottom.addView(torchBtn, lp(dp(64), dp(64)))
        bottom.addView(mono("SWIPE UP TO UNLOCK", 10f, Pal.SUB).apply { gravity = Gravity.CENTER }, lp(0, WRAP, 1f))
        bottom.addView(roundButton("CAM") {
            try {
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {}
        }, lp(dp(64), dp(64)))
        content.addView(bottom, lp(MATCH, WRAP).apply { topMargin = dp(12) })

        try {
            val c = cam
            if (c != null) {
                torchId = c.cameraIdList.firstOrNull {
                    c.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                c.registerTorchCallback(torchCb, main)
            }
        } catch (e: Exception) {
        }
        styleTorch()
    }

    override fun onResume() {
        super.onResume()
        if (!isLocked()) {
            finish()
            return
        }
        visible = true
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(receiver, f)
        } catch (e: Exception) {}
        NotifService.onChangeLock = { buildNotifs() }
        update()
    }

    override fun onPause() {
        super.onPause()
        visible = false
        NotifService.onChangeLock = null
        try { unregisterReceiver(receiver) } catch (e: Exception) {}
    }

    override fun onDestroy() {
        if (unlockRegistered) try { unregisterReceiver(unlockReceiver) } catch (e: Exception) {}
        try { cam?.unregisterTorchCallback(torchCb) } catch (e: Exception) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Stay on the lock screen.
    }

    private fun isLocked(): Boolean = try {
        getSystemService(KeyguardManager::class.java).isKeyguardLocked
    } catch (e: Exception) {
        false
    }

    private fun unlock() {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                finish()
            }
        })
    }

    private fun update() {
        if (!::hours.isInitialized) return
        val now = Date()
        val us = Locale.US
        hours.text = SimpleDateFormat(if (prefs.clock24) "HH" else "hh", us).format(now)
        minutes.text = SimpleDateFormat("mm", us).format(now)
        dateView.text = SimpleDateFormat("EEEE d MMMM", us).format(now).uppercase(us)

        val bat = try { registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (e: Exception) { null }
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val parts = ArrayList<String>()
        if (lvl >= 0 && scale > 0) parts.add((if (charging) "CHARGING " else "") + "${lvl * 100 / scale}%")
        val next = try { getSystemService(AlarmManager::class.java).nextAlarmClock } catch (e: Exception) { null }
        if (next != null) {
            parts.add("ALARM " + SimpleDateFormat(if (prefs.clock24) "HH:mm" else "h:mm a", us)
                .format(Date(next.triggerTime)).uppercase(us))
        }
        infoView.text = parts.joinToString("  ·  ")
        buildNotifs()
    }

    /** Notifications grouped by app. Text is only shown if the user turned it on. */
    private fun buildNotifs() {
        if (!::notifBox.isInitialized) return
        notifBox.removeAllViews()
        val items = NotifService.current().filter { sbn ->
            val n = sbn.notification
            (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                (n.flags and Notification.FLAG_ONGOING_EVENT) == 0 &&
                sbn.packageName != packageName &&
                !n.extras.getCharSequence(Notification.EXTRA_TITLE).isNullOrEmpty()
        }.sortedByDescending { it.postTime }
        if (items.isEmpty()) return
        val showText = prefs.lockDetails
        val groups = LinkedHashMap<String, MutableList<android.service.notification.StatusBarNotification>>()
        for (s in items) groups.getOrPut(s.packageName) { ArrayList() }.add(s)

        for ((pkg, list) in groups) {
            val first = list[0]
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(0xE6111111.toInt(), dp(22f))
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val icon = ImageView(this)
            try {
                val d = first.notification.smallIcon?.loadDrawable(this)
                d?.setTint(Color.WHITE)
                icon.setImageDrawable(d)
            } catch (e: Exception) {}
            top.addView(icon, lp(dp(16), dp(16)))
            top.addView(mono(appName(pkg), 11f, Pal.TEXT), lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
            if (list.size > 1) top.addView(mono("${list.size}", 11f, Pal.RED), lp(WRAP, WRAP))
            card.addView(top, lp(MATCH, WRAP))
            if (showText) {
                val ex = first.notification.extras
                val t = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val b = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
                card.addView(TextView(this).apply {
                    text = t
                    textSize = 14f
                    setTextColor(Color.WHITE)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }, lp(MATCH, WRAP).apply { topMargin = dp(8) })
                if (b.isNotEmpty()) card.addView(TextView(this).apply {
                    text = b
                    textSize = 12.5f
                    setTextColor(0xFFB4B4B4.toInt())
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                }, lp(MATCH, WRAP).apply { topMargin = dp(2) })
            }
            card.isClickable = true
            card.setOnClickListener { unlock() }
            notifBox.addView(card, lp(MATCH, WRAP).apply { topMargin = dp(8) })
        }
    }

    private fun toggleTorch() {
        val id = torchId ?: return
        try { cam?.setTorchMode(id, !torchOn) } catch (e: Exception) {}
    }

    private fun styleTorch() {
        if (!::torchBtn.isInitialized) return
        torchBtn.background = rounded(if (torchOn) Color.WHITE else 0xFF1C1C1C.toInt(), dp(32f))
        torchBtn.setTextColor(if (torchOn) Color.BLACK else Color.WHITE)
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg.substringAfterLast('.')
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun rounded(color: Int, r: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r
    }

    private fun mono(t: String, sp: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.1f
        isAllCaps = true
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun roundButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 9f
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.1f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(0xFF1C1C1C.toInt(), dp(32f))
        isClickable = true
        setOnClickListener { onClick() }
    }
}
