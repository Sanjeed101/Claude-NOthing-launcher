package com.dotlauncher.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.location.Geocoder
import android.view.View
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

data class WeatherData(val temp: Int, val code: Int, val hi: Int, val lo: Int)

/** Weather from Open-Meteo (free, no API key). */
object Weather {
    fun fetch(lat: Double, lon: Double): WeatherData {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code" +
                "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
        )
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        try {
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(body)
            val cur = j.getJSONObject("current")
            val d = j.getJSONObject("daily")
            return WeatherData(
                cur.getDouble("temperature_2m").roundToInt(),
                cur.getInt("weather_code"),
                d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
            )
        } finally {
            c.disconnect()
        }
    }

    fun city(ctx: Context, lat: Double, lon: Double): String = try {
        @Suppress("DEPRECATION")
        val a = Geocoder(ctx, Locale.US).getFromLocation(lat, lon, 1)?.firstOrNull()
        (a?.locality ?: a?.subAdminArea ?: a?.adminArea).orEmpty()
    } catch (e: Exception) {
        ""
    }

    fun label(code: Int): String = when (code) {
        0 -> "CLEAR"
        1, 2 -> "PARTLY CLOUDY"
        3 -> "CLOUDY"
        45, 48 -> "FOG"
        in 51..57 -> "DRIZZLE"
        in 61..67 -> "RAIN"
        in 71..77 -> "SNOW"
        in 80..82 -> "SHOWERS"
        85, 86 -> "SNOW SHOWERS"
        in 95..99 -> "THUNDERSTORM"
        else -> "—"
    }

    /** Dot-matrix icon glyph (see DotFont). */
    fun glyph(code: Int): String = when (code) {
        0 -> "☀"
        1, 2, 3 -> "☁"
        45, 48 -> "≡"
        in 71..77, 85, 86 -> "❄"
        in 95..99 -> "⚡"
        in 51..67, in 80..82 -> "☂"
        else -> "☁"
    }
}

/** Analog clock drawn with dots: 60 minute dots, hour markers, dotted hands. */
class AnalogDotClock(ctx: Context) : View(ctx) {
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT }
    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.DOT_OFF }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.RED }
    private val maxSize = ctx.dp(190)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val mode = MeasureSpec.getMode(widthMeasureSpec)
        val size = if (mode == MeasureSpec.UNSPECIFIED) maxSize else MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(size, min(size, maxSize))
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s / 2f * 0.92f
        val small = s * 0.011f
        val big = s * 0.022f
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0)
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            when {
                i == 0 -> canvas.drawCircle(x, y, big * 1.3f, red)
                i % 5 == 0 -> canvas.drawCircle(x, y, big, on)
                else -> canvas.drawCircle(x, y, small, dim)
            }
        }
        val cal = Calendar.getInstance()
        val mins = cal.get(Calendar.MINUTE)
        val hr = cal.get(Calendar.HOUR) + mins / 60f
        hand(canvas, cx, cy, hr * 30.0, r * 0.5f, big, on)
        hand(canvas, cx, cy, mins * 6.0, r * 0.78f, big * 0.8f, on)
        canvas.drawCircle(cx, cy, big * 1.6f, red)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Double, len: Float, dotR: Float, p: Paint) {
        val a = Math.toRadians(deg - 90.0)
        val step = dotR * 2.8f
        var d = step * 1.6f
        while (d <= len) {
            c.drawCircle(cx + (d * cos(a)).toFloat(), cy + (d * sin(a)).toFloat(), dotR, p)
            d += step
        }
    }
}
