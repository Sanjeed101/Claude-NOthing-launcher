package com.dotlauncher.app

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlarmManager
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max

class MainActivity : Activity() {

    companion object {
        @Volatile
        var apps: List<AppItem> = emptyList()
        private val exec = Executors.newSingleThreadExecutor()
        private val netExec = Executors.newSingleThreadExecutor()

        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        private const val REQ_BIND = 101
        private const val REQ_CONFIG = 102
        private const val REQ_LOCATION = 103
        private const val HOST_ID = 0x4D07

        private val GESTURE_NAMES = arrayOf("Swipe up", "Swipe down", "Swipe left", "Swipe right", "Double-tap")
        private val ACTION_CODES = arrayOf("drawer", "search", "panel", "notifications", "quicksettings", "lock", "none", "app")
        private val ACTION_LABELS = arrayOf(
            "Open app drawer", "Search apps", "Quick panel (Nothing style)", "System notifications",
            "System quick settings", "Lock screen", "Do nothing", "Open an app…"
        )
        private val BUILTIN_WIDGETS = linkedMapOf(
            "clock" to "Dot clock",
            "datebat" to "Date & battery",
            "weather" to "Weather",
            "analog" to "Analog dot clock"
        )
    }

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var home: SwipeFrame
    private lateinit var drawer: SwipeFrame
    private lateinit var panel: QuickPanel
    private lateinit var drawerContent: LinearLayout
    private lateinit var drawerGrid: GridView
    private lateinit var drawerCount: TextView
    private lateinit var search: EditText
    private val appAdapter = AppAdapter()

    private var homeContent: LinearLayout? = null
    private var widgetScroll: ScrollView? = null
    private var pinsContainer: LinearLayout? = null
    private var clockView: DotTextView? = null
    private var analogView: AnalogDotClock? = null
    private var weekdayView: DotTextView? = null
    private var dateText: TextView? = null
    private var alarmText: TextView? = null
    private var batteryView: BatteryDotsView? = null
    private var batteryLabel: TextView? = null
    private var lastBattery: Intent? = null
    private var weatherTemp: DotTextView? = null
    private var weatherIcon: DotTextView? = null
    private var weatherCond: TextView? = null
    private var weatherMeta: TextView? = null
    private var weatherLoading = false

    private var pendingWidgetId = -1
    private val bars = Rect()
    private var imeBottom = 0
    private var drawerOpen = false
    private val main = Handler(Looper.getMainLooper())
    private val launcherApps: LauncherApps by lazy { getSystemService(LauncherApps::class.java) }
    private val imm: InputMethodManager by lazy { getSystemService(InputMethodManager::class.java) }
    private val widgetManager: AppWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private val widgetHost: AppWidgetHost by lazy { AppWidgetHost(applicationContext, HOST_ID) }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setupWindow()

        root = FrameLayout(this)
        home = SwipeFrame(this)
        drawer = SwipeFrame(this)
        panel = QuickPanel(this) { prefs.clock24 }
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(panel.view, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        home.onLongPressAction = { showHomeMenu() }
        home.canIntercept = { d -> homeCanIntercept(d) }
        applyGestures()

        drawer.enabledDirs = setOf(SwipeFrame.DOWN)
        drawer.canIntercept = { gridAtTop() }
        drawer.onSwipe = { closeDrawer(true) }
        drawer.isClickable = true
        drawer.visibility = View.GONE

        root.setOnApplyWindowInsetsListener { _, wi ->
            readInsets(wi)
            applyInsets()
            wi
        }

        NotifService.onChange = { if (panel.isOpen) panel.refresh() }

        buildDrawer()
        buildHome()
        filter()

        try {
            launcherApps.registerCallback(packageCallback, main)
        } catch (e: Exception) {
        }
        reloadApps()
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (e: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        try { widgetHost.stopListening() } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        val time = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
        }
        register(timeReceiver, time)
        register(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { onBattery(it) }
        updateClock()
        refreshWeather(false)
        if (panel.isOpen) panel.refresh()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(timeReceiver) } catch (e: Exception) {}
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) {}
    }

    override fun onDestroy() {
        try { launcherApps.unregisterCallback(packageCallback) } catch (e: Exception) {}
        NotifService.onChange = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while we're already in front: go back to the home page.
        if (Intent.ACTION_MAIN == intent.action) {
            val anim = hasWindowFocus()
            closeDrawer(anim)
            panel.close(anim)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panel.isOpen) panel.close()
        else if (drawerOpen) closeDrawer(true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        if (id == -1) return
        when (requestCode) {
            REQ_BIND -> {
                val info = widgetManager.getAppWidgetInfo(id)
                if (resultCode == RESULT_OK && info != null) configureOrAddWidget(id, info)
                else discardPendingWidget()
            }
            REQ_CONFIG -> {
                if (resultCode == RESULT_OK) addWidgetEntry("sys:$id") else discardPendingWidget()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) refreshWeather(true)
    }

    // ---------------------------------------------------------------- window / insets

    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
    }

    private fun readInsets(wi: WindowInsets) {
        if (Build.VERSION.SDK_INT >= 30) {
            val s = wi.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            bars.set(s.left, s.top, s.right, s.bottom)
            imeBottom = wi.getInsets(WindowInsets.Type.ime()).bottom
        } else {
            @Suppress("DEPRECATION")
            bars.set(wi.systemWindowInsetLeft, wi.systemWindowInsetTop,
                wi.systemWindowInsetRight, wi.systemWindowInsetBottom)
            imeBottom = 0
        }
    }

    private fun applyInsets() {
        val pad = dp(if (isWide()) 28 else 18)
        homeContent?.setPadding(bars.left + pad, bars.top + dp(16), bars.right + pad, bars.bottom + dp(14))
        if (::drawerContent.isInitialized) {
            drawerContent.setPadding(bars.left + pad, bars.top + dp(16), bars.right + pad,
                max(bars.bottom, imeBottom))
        }
        if (::panel.isInitialized) panel.setInsets(bars.left, bars.top, bars.right, bars.bottom)
    }

    // ---------------------------------------------------------------- sizing

    private fun widthDp() = resources.configuration.screenWidthDp
    private fun isWide() = widthDp() >= 600
    private fun homeCols() = if (isWide()) ((widthDp() * 0.55f) / 92f).toInt().coerceIn(4, 6)
                             else (widthDp() / 84).coerceIn(4, 5)
    private fun drawerCols() = (widthDp() / 92).coerceIn(4, 8)
    private fun iconPx() = dp(if (isWide()) 56 else 54)

    // ---------------------------------------------------------------- gestures

    private fun applyGestures() {
        val dirs = HashSet<Int>()
        for (d in 0..3) if (prefs.gesture(d) != "none") dirs.add(d)
        home.enabledDirs = dirs
        home.onSwipe = { d -> runAction(prefs.gesture(d)) }
        home.onDoubleTapAction = if (prefs.gesture(SwipeFrame.DOUBLE) != "none") {
            { runAction(prefs.gesture(SwipeFrame.DOUBLE)) }
        } else null
    }

    private fun homeCanIntercept(d: Int): Boolean {
        val s = widgetScroll ?: return true
        val r = Rect()
        if (!s.getGlobalVisibleRect(r) || !r.contains(home.downRawX.toInt(), home.downRawY.toInt())) return true
        return when (d) {
            SwipeFrame.UP -> !s.canScrollVertically(1)
            SwipeFrame.DOWN -> !s.canScrollVertically(-1)
            else -> true
        }
    }

    private fun runAction(a: String) {
        when {
            a == "drawer" -> openDrawer(false)
            a == "search" -> openDrawer(true)
            a == "panel" -> { closeDrawer(false); panel.open() }
            a == "notifications" -> systemShade(false)
            a == "quicksettings" -> systemShade(true)
            a == "lock" -> lockScreen()
            a.startsWith("app:") -> {
                val app = apps.firstOrNull { it.key == a.removePrefix("app:") }
                if (app != null) launch(app, home) else toast("That app isn't installed any more")
            }
        }
    }

    private fun systemShade(quickSettings: Boolean) {
        val svc = LockService.instance
        if (svc != null) {
            svc.performGlobalAction(
                if (quickSettings) AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                else AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            )
            return
        }
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod(if (quickSettings) "expandSettingsPanel" else "expandNotificationsPanel")
                .invoke(sb)
        } catch (e: Throwable) {
        }
    }

    private fun lockScreen() {
        val svc = LockService.instance
        if (svc != null && svc.lock()) return
        promptAccessibility("To lock the screen with a gesture")
    }

    private fun promptAccessibility(reason: String) {
        AlertDialog.Builder(this)
            .setTitle("Turn on Dot Launcher gestures")
            .setMessage(
                "$reason, Dot Launcher needs its accessibility service.\n\n" +
                    "Settings → Accessibility → Installed apps → Dot Launcher → turn on.\n\n" +
                    "If the switch is greyed out: open App info, tap ⋮ (top right) → " +
                    "Allow restricted settings, then try again."
            )
            .setPositiveButton("Accessibility") { _, _ -> safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNeutralButton("App info") { _, _ ->
                safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun actionLabel(code: String): String {
        if (code.startsWith("app:")) {
            val app = apps.firstOrNull { it.key == code.removePrefix("app:") }
            return "Open " + (app?.label ?: "app")
        }
        val i = ACTION_CODES.indexOf(code)
        return if (i >= 0) ACTION_LABELS[i] else code
    }

    private fun showGestures() {
        val items = GESTURE_NAMES.mapIndexed { i, n -> "$n  →  ${actionLabel(prefs.gesture(i))}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Gestures")
            .setItems(items) { _, which -> chooseGestureAction(which) }
            .setNegativeButton("Done", null)
            .show()
    }

    private fun chooseGestureAction(g: Int) {
        AlertDialog.Builder(this)
            .setTitle(GESTURE_NAMES[g])
            .setItems(ACTION_LABELS) { _, which ->
                val code = ACTION_CODES[which]
                if (code == "app") {
                    pickApp { key ->
                        prefs.setGesture(g, "app:$key")
                        applyGestures()
                        showGestures()
                    }
                } else {
                    prefs.setGesture(g, code)
                    applyGestures()
                    if (code == "lock" && LockService.instance == null) lockScreen() else showGestures()
                }
            }
            .show()
    }

    private fun pickApp(onPicked: (String) -> Unit) {
        val list = apps.filter { it.key !in prefs.hidden }
        if (list.isEmpty()) {
            toast("Apps are still loading")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Choose an app")
            .setItems(list.map { it.label }.toTypedArray()) { _, which -> onPicked(list[which].key) }
            .show()
    }

    // ---------------------------------------------------------------- home

    private fun buildHome() {
        home.removeAllViews()
        home.background = if (prefs.dotGrid) DotGridDrawable(dp(22f), dp(1.3f), Pal.GRID)
                          else ColorDrawable(Pal.BG)
        val wide = isWide()
        val content = LinearLayout(this).apply {
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        }
        homeContent = content
        home.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = true
        }
        widgetScroll = scroll
        val stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (wide) gravity = Gravity.CENTER_VERTICAL
        }
        scroll.addView(stack, FrameLayout.LayoutParams(MATCH, WRAP))
        buildWidgets(stack, wide)

        val pinsBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pins = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pinsContainer = pins
        pinsBlock.addView(pins, lp(MATCH, WRAP))
        pinsBlock.addView(searchPill(), lp(MATCH, dp(52)).apply { topMargin = dp(22) })

        if (wide) {
            content.addView(scroll, lp(0, MATCH, 1f).apply { rightMargin = dp(32) })
            val appsCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            appsCol.addView(View(this), lp(MATCH, 0, 1f))
            appsCol.addView(pinsBlock, lp(MATCH, WRAP))
            content.addView(appsCol, lp(0, MATCH, 1.25f))
        } else {
            content.addView(scroll, lp(MATCH, 0, 1f))
            content.addView(pinsBlock, lp(MATCH, WRAP).apply { topMargin = dp(16) })
        }

        applyInsets()
        updateClock()
        lastBattery?.let { onBattery(it) }
        renderWeather()
        renderPins()
    }

    private fun buildWidgets(stack: LinearLayout, wide: Boolean) {
        clockView = null; analogView = null; weekdayView = null; dateText = null; alarmText = null
        batteryView = null; batteryLabel = null
        weatherTemp = null; weatherIcon = null; weatherCond = null; weatherMeta = null

        val entries = prefs.widgets
        var first = true
        for (e in entries) {
            val v = buildWidget(e, wide) ?: continue
            stack.addView(v, lp(MATCH, WRAP).apply { if (!first) topMargin = dp(12) })
            first = false
        }
        if (entries.isEmpty()) {
            stack.addView(monoText("LONG-PRESS EMPTY SPACE TO ADD WIDGETS", 10f, Pal.DOT_OFF).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, dp(40))
            }, lp(MATCH, WRAP))
        }
    }

    private fun buildWidget(entry: String, wide: Boolean): View? {
        val v: View = when {
            entry == "clock" -> clockWidget(wide)
            entry == "datebat" -> dateBatteryWidget()
            entry == "weather" -> weatherWidget(wide)
            entry == "analog" -> analogWidget()
            entry.startsWith("sys:") -> systemWidget(entry, wide) ?: return null
            else -> return null
        }
        if (!entry.startsWith("sys:")) {
            setLongPressRecursive(v) { widgetMenu(entry) }
        }
        return v
    }

    private fun setLongPressRecursive(v: View, action: () -> Unit) {
        if (v.isClickable || v is ViewGroup) {
            v.setOnLongClickListener { action(); true }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) setLongPressRecursive(v.getChildAt(i), action)
    }

    private fun clockWidget(wide: Boolean): View {
        val c = card()
        val cv = DotTextView(this).apply {
            maxPitch = dp(if (wide) 17f else 15f)
            accentChars = ":"
            centered = true
        }
        clockView = cv
        c.addView(cv, lp(MATCH, WRAP).apply { topMargin = dp(8); bottomMargin = dp(8) })
        c.setOnClickListener { safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        return c
    }

    private fun dateBatteryWidget(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dateCard = card()
        val wd = DotTextView(this).apply { maxPitch = dp(7f) }
        weekdayView = wd
        dateCard.addView(wd, lp(MATCH, WRAP))
        val dt = monoText("", 12f, Pal.TEXT)
        dateText = dt
        dateCard.addView(dt, lp(MATCH, WRAP).apply { topMargin = dp(14) })
        dateCard.addView(View(this), lp(MATCH, 0, 1f))
        val at = monoText("", 11f, Pal.SUB)
        alarmText = at
        dateCard.addView(at, lp(MATCH, WRAP).apply { topMargin = dp(14) })
        dateCard.setOnClickListener {
            safeStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR))
        }
        row.addView(dateCard, lp(0, MATCH, 1f).apply { rightMargin = dp(12) })

        val batCard = card()
        batCard.gravity = Gravity.CENTER_HORIZONTAL
        val bv = BatteryDotsView(this)
        batteryView = bv
        batCard.addView(bv, lp(MATCH, WRAP))
        val bl = monoText("BATTERY", 10f, Pal.SUB).apply { gravity = Gravity.CENTER }
        batteryLabel = bl
        batCard.addView(bl, lp(MATCH, WRAP).apply { topMargin = dp(10) })
        batCard.setOnClickListener { safeStart(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }
        row.addView(batCard, lp(0, WRAP, 1f))
        return row
    }

    private fun weatherWidget(wide: Boolean): View {
        val c = card()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val t = DotTextView(this).apply { maxPitch = dp(if (wide) 10f else 9f) }
        weatherTemp = t
        top.addView(t, lp(0, WRAP, 1f))
        val ic = DotTextView(this).apply { maxPitch = dp(6f); color = Pal.RED }
        weatherIcon = ic
        top.addView(ic, lp(WRAP, WRAP))
        c.addView(top, lp(MATCH, WRAP))
        val cond = monoText("", 12f, Pal.TEXT)
        weatherCond = cond
        c.addView(cond, lp(MATCH, WRAP).apply { topMargin = dp(14) })
        val meta = monoText("", 11f, Pal.SUB)
        weatherMeta = meta
        c.addView(meta, lp(MATCH, WRAP).apply { topMargin = dp(6) })
        c.setOnClickListener {
            if (!hasLocationPermission()) requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOCATION)
            else refreshWeather(true)
        }
        return c
    }

    private fun analogWidget(): View {
        val c = card()
        c.gravity = Gravity.CENTER_HORIZONTAL
        val a = AnalogDotClock(this)
        analogView = a
        c.addView(a, lp(MATCH, WRAP).apply { topMargin = dp(4); bottomMargin = dp(4) })
        c.setOnClickListener { safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        return c
    }

    private fun systemWidget(entry: String, wide: Boolean): View? {
        val id = entry.removePrefix("sys:").toIntOrNull() ?: return null
        val info = widgetManager.getAppWidgetInfo(id) ?: return null
        val hv = try { widgetHost.createView(applicationContext, id, info) } catch (e: Exception) { return null }
        val density = resources.displayMetrics.density
        val hPx = max(max(info.minHeight, dp(90)), dp(110))
        val wDp = if (wide) (widthDp() * 0.42f).toInt() else widthDp() - 36
        val hDp = (hPx / density).toInt()
        try {
            @Suppress("DEPRECATION")
            hv.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp)
        } catch (e: Exception) {}
        val frame = FrameLayout(this).apply {
            background = rounded(Pal.CARD, dp(26f))
            clipToOutline = true
        }
        frame.addView(hv, FrameLayout.LayoutParams(MATCH, hPx))
        return frame
    }

    private fun widgetLabel(entry: String): String {
        BUILTIN_WIDGETS[entry]?.let { return it }
        val id = entry.removePrefix("sys:").toIntOrNull() ?: return entry
        val info = widgetManager.getAppWidgetInfo(id) ?: return "Widget"
        return appLabelFor(info.provider.packageName) + " — " + info.loadLabel(packageManager)
    }

    private fun appLabelFor(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        apps.firstOrNull { it.component.packageName == pkg }?.label ?: pkg
    }

    private fun showHomeMenu() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Add widget", "Edit widgets", "Gestures", "Settings")) { _, which ->
                when (which) {
                    0 -> showAddWidget()
                    1 -> showEditWidgets()
                    2 -> showGestures()
                    3 -> showSettings()
                }
            }
            .show()
    }

    private fun showAddWidget() {
        val keys = BUILTIN_WIDGETS.keys.toList()
        val labels = BUILTIN_WIDGETS.values.toList() + "Android widgets (WhatsApp, Gmail…)"
        AlertDialog.Builder(this)
            .setTitle("Add widget")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < keys.size) {
                    val k = keys[which]
                    if (k in prefs.widgets) toast("That widget is already on your home screen")
                    else {
                        addWidgetEntry(k)
                        if (k == "weather" && !hasLocationPermission()) {
                            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOCATION)
                        }
                    }
                } else {
                    pickSystemWidget()
                }
            }
            .show()
    }

    private fun addWidgetEntry(e: String) {
        pendingWidgetId = -1
        prefs.widgets = prefs.widgets + e
        buildHome()
        refreshWeather(false)
        main.post { widgetScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showEditWidgets() {
        val entries = prefs.widgets
        if (entries.isEmpty()) {
            toast("No widgets yet")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Edit widgets")
            .setItems(entries.map { widgetLabel(it) }.toTypedArray()) { _, which -> widgetMenu(entries[which]) }
            .setNegativeButton("Done", null)
            .show()
    }

    private fun widgetMenu(entry: String) {
        AlertDialog.Builder(this)
            .setTitle(widgetLabel(entry))
            .setItems(arrayOf("Move up", "Move down", "Remove")) { _, which ->
                val l = prefs.widgets.toMutableList()
                val i = l.indexOf(entry)
                if (i < 0) return@setItems
                when (which) {
                    0 -> if (i > 0) { l[i] = l[i - 1]; l[i - 1] = entry }
                    1 -> if (i < l.size - 1) { l[i] = l[i + 1]; l[i + 1] = entry }
                    2 -> {
                        l.removeAt(i)
                        entry.removePrefix("sys:").toIntOrNull()?.let {
                            if (entry.startsWith("sys:")) try { widgetHost.deleteAppWidgetId(it) } catch (e: Exception) {}
                        }
                    }
                }
                prefs.widgets = l
                buildHome()
            }
            .show()
    }

    private fun pickSystemWidget() {
        val providers = try { widgetManager.installedProviders } catch (e: Exception) { emptyList() }
        if (providers.isEmpty()) {
            toast("No widgets found")
            return
        }
        val sorted = providers.map { p -> Pair(p, appLabelFor(p.provider.packageName) + " — " + p.loadLabel(packageManager)) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.second })
        AlertDialog.Builder(this)
            .setTitle("Android widgets")
            .setItems(sorted.map { it.second }.toTypedArray()) { _, which -> bindWidget(sorted[which].first) }
            .show()
    }

    private fun bindWidget(p: AppWidgetProviderInfo) {
        val id = try { widgetHost.allocateAppWidgetId() } catch (e: Exception) { return }
        pendingWidgetId = id
        val ok = try { widgetManager.bindAppWidgetIdIfAllowed(id, p.provider) } catch (e: Exception) { false }
        if (ok) {
            configureOrAddWidget(id, p)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                discardPendingWidget()
            }
        }
    }

    private fun configureOrAddWidget(id: Int, p: AppWidgetProviderInfo) {
        if (p.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
                return
            } catch (e: Exception) {
            }
        }
        addWidgetEntry("sys:$id")
    }

    private fun discardPendingWidget() {
        val id = pendingWidgetId
        pendingWidgetId = -1
        if (id != -1) try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) {}
    }

    private fun searchPill(): View {
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Pal.CARD, dp(26f))
            setPadding(dp(22), 0, dp(22), 0)
            isClickable = true
        }
        val dot = View(this).apply { background = rounded(Pal.RED, dp(4f)) }
        pill.addView(dot, lp(dp(8), dp(8)))
        pill.addView(monoText("SEARCH", 12f, Pal.SUB), lp(0, WRAP, 1f).apply { leftMargin = dp(14) })
        pill.addView(DotTextView(this).apply { text = "..."; maxPitch = dp(3f); color = Pal.SUB }, lp(WRAP, WRAP))
        pill.setOnClickListener { openDrawer(true) }
        return pill
    }

    private fun renderPins() {
        val container = pinsContainer ?: return
        container.removeAllViews()
        val byKey = apps.associateBy { it.key }
        val pinned = prefs.pins.mapNotNull { byKey[it] }
        if (pinned.isEmpty()) return
        val cols = homeCols()
        val size = iconPx()
        pinned.chunked(cols).forEachIndexed { i, rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (a in rowApps) row.addView(homeCell(a, size), lp(0, WRAP, 1f))
            repeat(cols - rowApps.size) { row.addView(View(this), lp(0, 1, 1f)) }
            container.addView(row, lp(MATCH, WRAP).apply { if (i > 0) topMargin = dp(16) })
        }
    }

    private fun homeCell(app: AppItem, size: Int): View {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val iv = ImageView(this)
        iv.setImageBitmap(Icons.get(this, app, size, prefs.mono))
        cell.addView(iv, LinearLayout.LayoutParams(size, size))
        if (prefs.labels) {
            cell.addView(labelView(app.label), lp(MATCH, WRAP).apply { topMargin = dp(7) })
        }
        cell.setOnClickListener { launch(app, iv) }
        cell.setOnLongClickListener { showAppMenu(app, it, fromHome = true); true }
        return cell
    }

    // ---------------------------------------------------------------- weather

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun renderWeather() {
        val t = weatherTemp ?: return
        if (prefs.wTime == 0L) {
            t.text = "--°"
            weatherIcon?.text = "☁"
            if (!hasLocationPermission()) {
                weatherCond?.text = "TAP TO SET UP WEATHER"
                weatherMeta?.text = "USES APPROXIMATE LOCATION"
            } else {
                weatherCond?.text = if (weatherLoading) "LOADING…" else "TAP TO REFRESH"
                weatherMeta?.text = ""
            }
            return
        }
        t.text = "${prefs.wTemp}°"
        weatherIcon?.text = Weather.glyph(prefs.wCode)
        weatherCond?.text = Weather.label(prefs.wCode)
        val city = prefs.wCity
        weatherMeta?.text = "H ${prefs.wHi}°  L ${prefs.wLo}°" + if (city.isNotEmpty()) "  ·  $city" else ""
    }

    private fun refreshWeather(force: Boolean) {
        if ("weather" !in prefs.widgets) return
        val fresh = System.currentTimeMillis() - prefs.wTime < 30 * 60 * 1000L
        if (!force && fresh) {
            renderWeather()
            return
        }
        if (!hasLocationPermission() || weatherLoading) {
            renderWeather()
            return
        }
        weatherLoading = true
        renderWeather()
        val lm = getSystemService(LocationManager::class.java)
        val last: Location? = try {
            lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        } catch (e: SecurityException) {
            null
        }
        if (last != null) {
            fetchWeather(last.latitude, last.longitude)
        } else if (Build.VERSION.SDK_INT >= 30) {
            try {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { loc ->
                    if (loc != null) fetchWeather(loc.latitude, loc.longitude) else fallbackWeather()
                }
            } catch (e: Exception) {
                fallbackWeather()
            }
        } else {
            fallbackWeather()
        }
    }

    private fun fallbackWeather() {
        if (prefs.wLat != 0f || prefs.wLon != 0f) fetchWeather(prefs.wLat.toDouble(), prefs.wLon.toDouble())
        else {
            weatherLoading = false
            renderWeather()
            toast("Couldn't get your location. Turn on Location and tap the weather card.")
        }
    }

    private fun fetchWeather(lat: Double, lon: Double) {
        val ctx = applicationContext
        netExec.execute {
            val data = try { Weather.fetch(lat, lon) } catch (e: Exception) { null }
            val city = if (data != null) Weather.city(ctx, lat, lon) else ""
            main.post {
                weatherLoading = false
                if (data != null) {
                    prefs.saveWeather(data, city.uppercase(Locale.US), lat.toFloat(), lon.toFloat())
                } else if (!isDestroyed) {
                    toast("Weather update failed. Check your internet connection.")
                }
                if (!isDestroyed) renderWeather()
            }
        }
    }

    // ---------------------------------------------------------------- drawer

    private fun buildDrawer() {
        drawer.setBackgroundColor(Pal.BG)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        drawerContent = col
        drawer.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(DotTextView(this).apply { text = "APPS"; maxPitch = dp(6f) }, lp(WRAP, WRAP))
        header.addView(View(this), lp(0, 1, 1f))
        drawerCount = monoText("", 11f, Pal.SUB)
        header.addView(drawerCount, lp(WRAP, WRAP))
        col.addView(header, lp(MATCH, WRAP).apply { topMargin = dp(10) })

        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Pal.SUB)
            setTextColor(Pal.TEXT)
            textSize = 15f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = rounded(Pal.CARD, dp(26f))
            setPadding(dp(22), 0, dp(22), 0)
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            appAdapter.items.firstOrNull()?.let { launch(it, search) }
            true
        }
        col.addView(search, lp(MATCH, dp(52)).apply { topMargin = dp(20) })

        drawerGrid = GridView(this).apply {
            adapter = appAdapter
            numColumns = drawerCols()
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(22)
            selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(0, dp(22), 0, dp(24))
        }
        drawerGrid.setOnItemClickListener { _, view, pos, _ ->
            appAdapter.items.getOrNull(pos)?.let { launch(it, view) }
        }
        drawerGrid.setOnItemLongClickListener { _, view, pos, _ ->
            appAdapter.items.getOrNull(pos)?.let { showAppMenu(it, view, fromHome = false) }
            true
        }
        drawerGrid.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {
                if (scrollState != AbsListView.OnScrollListener.SCROLL_STATE_IDLE) hideKeyboard()
            }
            override fun onScroll(view: AbsListView?, first: Int, visible: Int, total: Int) {}
        })
        col.addView(drawerGrid, lp(MATCH, 0, 1f))
    }

    private fun filter() {
        if (!::search.isInitialized) return
        val q = search.text.toString().trim().lowercase(Locale.getDefault())
        val hidden = prefs.hidden
        val visible = apps.filter { it.key !in hidden }
        val list = if (q.isEmpty()) visible else visible
            .filter { it.label.lowercase(Locale.getDefault()).contains(q) }
            .sortedBy { if (it.label.lowercase(Locale.getDefault()).startsWith(q)) 0 else 1 }
        appAdapter.items = list
        appAdapter.notifyDataSetChanged()
        drawerCount.text = if (q.isEmpty()) "${visible.size}" else "${list.size} / ${visible.size}"
    }

    private fun gridAtTop(): Boolean {
        if (drawerGrid.childCount == 0) return true
        return drawerGrid.firstVisiblePosition == 0 && drawerGrid.getChildAt(0).top >= drawerGrid.paddingTop
    }

    private fun openDrawer(focusSearch: Boolean) {
        if (drawerOpen) return
        panel.close(false)
        drawerOpen = true
        filter()
        drawerGrid.setSelection(0)
        drawer.visibility = View.VISIBLE
        val h = if (root.height > 0) root.height.toFloat() else 2000f
        drawer.animate().cancel()
        drawer.translationY = h * 0.35f
        drawer.alpha = 0f
        drawer.animate().translationY(0f).alpha(1f).setDuration(240)
            .setInterpolator(DecelerateInterpolator(2f)).start()
        if (focusSearch) {
            search.requestFocus()
            main.postDelayed({ imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT) }, 150)
        }
    }

    private fun closeDrawer(animate: Boolean) {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        search.clearFocus()
        drawer.animate().cancel()
        if (animate) {
            val h = if (root.height > 0) root.height.toFloat() else 2000f
            drawer.animate().translationY(h * 0.35f).alpha(0f).setDuration(200)
                .setInterpolator(AccelerateInterpolator())
                .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
                .start()
        } else {
            drawer.visibility = View.GONE
        }
    }

    private fun hideKeyboard() {
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    private class Holder(val icon: ImageView, val label: TextView)

    private inner class AppAdapter : BaseAdapter() {
        var items: List<AppItem> = emptyList()

        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val size = iconPx()
            val view: View
            val holder: Holder
            if (convertView == null) {
                val cell = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                }
                val iv = ImageView(this@MainActivity)
                cell.addView(iv, LinearLayout.LayoutParams(size, size))
                val tv = labelView("")
                cell.addView(tv, lp(MATCH, WRAP).apply { topMargin = dp(7) })
                holder = Holder(iv, tv)
                cell.tag = holder
                view = cell
            } else {
                view = convertView
                holder = convertView.tag as Holder
            }
            val app = items[position]
            holder.icon.setImageBitmap(Icons.get(this@MainActivity, app, size, prefs.mono))
            holder.label.text = app.label
            return view
        }
    }

    // ---------------------------------------------------------------- apps

    private fun reloadApps() {
        val ctx = applicationContext
        val size = iconPx()
        val mono = prefs.mono
        exec.execute {
            val list = try { AppRepo.load(ctx) } catch (e: Exception) { emptyList() }
            for (a in list) Icons.get(ctx, a, size, mono)
            main.post {
                if (isDestroyed) return@post
                apps = list
                ensureDefaultPins()
                renderPins()
                filter()
            }
        }
    }

    private fun ensureDefaultPins() {
        if (prefs.pinsInitialized || apps.isEmpty()) return
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            Intent(Settings.ACTION_SETTINGS)
        )
        val pkgs = LinkedHashSet<String>()
        for (i in intents) {
            val ri = try { pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY) } catch (e: Exception) { null }
            val pkg = ri?.activityInfo?.packageName ?: continue
            if (pkg != "android") pkgs.add(pkg)
        }
        pkgs.add("com.whatsapp")
        val own = apps.filter { !it.work }
        val keys = pkgs.mapNotNull { p -> own.firstOrNull { it.component.packageName == p }?.key }
        prefs.pins = keys.take(8)
    }

    private val packageCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = reloadApps()
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = reloadApps()
        override fun onPackageChanged(packageName: String?, user: UserHandle?) {
            if (packageName != null) Icons.evict(packageName)
            reloadApps()
        }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = reloadApps()
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = reloadApps()
    }

    private fun launch(app: AppItem, v: View) {
        val bounds = Rect()
        v.getGlobalVisibleRect(bounds)
        val opts = ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()
        try {
            launcherApps.startMainActivity(app.component, app.user, bounds, opts)
        } catch (e: Exception) {
            toast("Can't open ${app.label}")
        }
    }

    private fun showAppMenu(app: AppItem, anchor: View, fromHome: Boolean) {
        val menu = PopupMenu(this, anchor)
        val pinned = prefs.pins.contains(app.key)
        if (fromHome) {
            menu.menu.add(0, 1, 0, "Remove from home")
            menu.menu.add(0, 2, 1, "Move left")
            menu.menu.add(0, 3, 2, "Move right")
        } else {
            if (pinned) menu.menu.add(0, 1, 0, "Remove from home")
            else menu.menu.add(0, 4, 0, "Add to home")
            menu.menu.add(0, 5, 1, "Hide app")
        }
        menu.menu.add(0, 6, 5, "App info")
        menu.menu.add(0, 7, 6, "Uninstall")
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> prefs.pins = prefs.pins - app.key
                2, 3 -> {
                    val l = prefs.pins.toMutableList()
                    val i = l.indexOf(app.key)
                    val j = if (item.itemId == 2) i - 1 else i + 1
                    if (i >= 0 && j in l.indices) {
                        val t = l[i]; l[i] = l[j]; l[j] = t
                        prefs.pins = l
                    }
                }
                4 -> { prefs.pins = prefs.pins + app.key; toast("Added to home") }
                5 -> { prefs.hidden = prefs.hidden + app.key; filter(); toast("Hidden. Unhide from launcher settings.") }
                6 -> try {
                    launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
                } catch (e: Exception) {}
                7 -> safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.component.packageName}")))
            }
            renderPins()
            true
        }
        menu.show()
    }

    // ---------------------------------------------------------------- settings

    private fun showSettings() {
        val names = arrayOf(
            "Monochrome icons", "Dot grid background", "24-hour clock", "Labels on home screen",
            "Dot panel in all apps (pull down from top edge)"
        )
        val checked = booleanArrayOf(prefs.mono, prefs.dotGrid, prefs.clock24, prefs.labels, prefs.edgePull)
        AlertDialog.Builder(this)
            .setTitle("Launcher settings")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Apply") { _, _ ->
                val monoChanged = prefs.mono != checked[0]
                prefs.mono = checked[0]
                prefs.dotGrid = checked[1]
                prefs.clock24 = checked[2]
                prefs.labels = checked[3]
                prefs.edgePull = checked[4]
                val svc = LockService.instance
                if (svc != null) svc.updateEdge()
                else if (checked[4]) promptAccessibility("To open the Dot panel from the top edge in every app")
                buildHome()
                filter()
                if (monoChanged) reloadApps()
            }
            .setNeutralButton("Hidden apps") { _, _ -> showHiddenApps() }
            .setNegativeButton("Default home app") { _, _ -> safeStart(Intent(Settings.ACTION_HOME_SETTINGS)) }
            .show()
    }

    private fun showHiddenApps() {
        val hiddenApps = apps.filter { it.key in prefs.hidden }
        if (hiddenApps.isEmpty()) {
            toast("No hidden apps")
            return
        }
        val names = hiddenApps.map { it.label }.toTypedArray()
        val keep = BooleanArray(hiddenApps.size) { true }
        AlertDialog.Builder(this)
            .setTitle("Hidden apps (untick to show)")
            .setMultiChoiceItems(names, keep) { _, which, isChecked -> keep[which] = isChecked }
            .setPositiveButton("Save") { _, _ ->
                prefs.hidden = hiddenApps.filterIndexed { i, _ -> keep[i] }.map { it.key }.toSet()
                filter()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- clock & battery

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateClock() }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { intent?.let { onBattery(it) } }
    }

    private fun register(r: BroadcastReceiver, f: IntentFilter): Intent? = try {
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(r, f)
    } catch (e: Exception) {
        null
    }

    private fun updateClock() {
        val now = Date()
        val us = Locale.US
        clockView?.text = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "h:mm", us).format(now)
        analogView?.invalidate()
        weekdayView?.text = SimpleDateFormat("EEE", us).format(now).uppercase(us)
        dateText?.text = SimpleDateFormat("d MMM", us).format(now).uppercase(us)
        val next = try { getSystemService(AlarmManager::class.java).nextAlarmClock } catch (e: Exception) { null }
        val label = if (next != null) {
            "ALARM " + SimpleDateFormat(if (prefs.clock24) "HH:mm" else "h:mm a", us)
                .format(Date(next.triggerTime)).uppercase(us)
        } else "NO ALARM"
        val span = SpannableString("●  $label")
        span.setSpan(ForegroundColorSpan(if (next != null) Pal.RED else Pal.DOT_OFF), 0, 1,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        alarmText?.text = span
        if (panel.isOpen) panel.refresh()
    }

    private fun onBattery(i: Intent) {
        lastBattery = i
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else 0
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        batteryView?.level = pct
        batteryView?.charging = charging
        batteryLabel?.text = if (charging) "CHARGING" else "BATTERY"
    }

    // ---------------------------------------------------------------- helpers

    private fun safeStart(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Not available on this phone")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Pal.CARD, dp(26f))
        setPadding(dp(18), dp(18), dp(18), dp(18))
        isClickable = true
    }

    private fun monoText(t: String, sizeSp: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = sizeSp
        setTextColor(color)
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.08f
        isAllCaps = true
    }

    private fun labelView(t: String) = TextView(this).apply {
        text = t
        textSize = 11.5f
        setTextColor(Pal.LABEL)
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
}
