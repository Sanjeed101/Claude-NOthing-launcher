package com.dotlauncher.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** Reads notifications so the quick panel can show them. Needs "Notification access". */
class NotifService : NotificationListenerService() {
    companion object {
        @Volatile
        var instance: NotifService? = null
        /** Listener for the launcher's own panel. */
        var onChange: (() -> Unit)? = null
        /** Listener for the system-wide overlay panel. */
        var onChangeOverlay: (() -> Unit)? = null
        private val main = Handler(Looper.getMainLooper())

        fun current(): List<StatusBarNotification> = try {
            instance?.activeNotifications?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

        fun changed() {
            main.post {
                onChange?.invoke()
                onChangeOverlay?.invoke()
            }
        }
    }

    override fun onListenerConnected() {
        instance = this
        changed()
    }

    override fun onListenerDisconnected() {
        instance = null
        changed()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = changed()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = changed()
}

/**
 * Accessibility service. Used for:
 *  - locking the screen and opening the system shade from home-screen gestures
 *  - (optional) a thin invisible strip over the status bar: pulling down from it in any app
 *    opens the Dot quick panel as an overlay instead of the Samsung panel.
 */
class LockService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: LockService? = null
    }

    private var wm: WindowManager? = null
    private var strip: View? = null
    private var panel: QuickPanel? = null
    private var panelAttached = false
    private var receiverOn = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    panel?.close(false)
                    removeStrip()
                }
                Intent.ACTION_USER_PRESENT, Intent.ACTION_SCREEN_ON -> updateEdge()
                @Suppress("DEPRECATION")
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS -> panel?.close()
            }
        }
    }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            @Suppress("DEPRECATION")
            addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(screenReceiver, f)
            receiverOn = true
        } catch (e: Exception) {
        }
        updateEdge()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeStrip()
        detachPanel()
        NotifService.onChangeOverlay = null
        if (receiverOn) {
            try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
            receiverOn = false
        }
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun lock(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    /** Adds or removes the top-edge strip according to the setting and the lock state. */
    fun updateEdge() {
        val locked = try { getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true } catch (e: Exception) { false }
        if (Prefs(this).edgePull && !locked) addStrip() else removeStrip()
    }

    private fun sysDimen(name: String, fallbackDp: Int): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(fallbackDp)
    }

    private fun overlayParams(w: Int, h: Int, flags: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= 30) lp.fitInsetsTypes = 0
        return lp
    }

    private fun addStrip() {
        if (strip != null) return
        val v = View(this)
        val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
        var downY = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - downY > slop) {
                    fired = true
                    openPanel()
                }
            }
            true
        }
        val lp = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            sysDimen("status_bar_height", 28),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        )
        try {
            wm?.addView(v, lp)
            strip = v
        } catch (e: Exception) {
        }
    }

    private fun removeStrip() {
        val v = strip ?: return
        try { wm?.removeView(v) } catch (e: Exception) {}
        strip = null
    }

    fun openPanel() {
        val p = panel ?: QuickPanel(this) { Prefs(this).clock24 }.also { qp ->
            panel = qp
            qp.onHidden = { detachPanel() }
            qp.view.onBack = { qp.close() }
            qp.view.isFocusableInTouchMode = true
        }
        if (!panelAttached) {
            val lp = overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                0
            )
            try {
                wm?.addView(p.view, lp)
                panelAttached = true
            } catch (e: Exception) {
                return
            }
            p.setInsets(0, sysDimen("status_bar_height", 28), 0, sysDimen("navigation_bar_height", 16))
        }
        NotifService.onChangeOverlay = { if (p.isOpen) p.refresh() }
        p.open()
    }

    private fun detachPanel() {
        val p = panel ?: return
        if (!panelAttached) return
        try { wm?.removeView(p.view) } catch (e: Exception) {}
        panelAttached = false
        NotifService.onChangeOverlay = null
    }
}
